def count_in_list(lst, element):
    """Count occurrences of an element in a list."""
    return lst.count(element)