# ft_package

A sample test package with a function to count occurrences in a list.
